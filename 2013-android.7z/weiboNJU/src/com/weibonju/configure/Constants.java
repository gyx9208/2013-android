package com.weibonju.configure;

public class Constants {
	public static final String APP_KEY="2954057970";
	public static final String REDIRECT_URL = "http://weibo.com";
	public static final String SCOPE = "email,direct_messages_read,direct_messages_write," +
			"friendships_groups_read,friendships_groups_write,statuses_to_me_read," +
			"follow_app_official_microblog";
	public static final String APP_SECRET="1e3ece93a24278c2d3df0578ff53108b";
	
	public static final String PREFERENCES_NAME = "weibo_nju";
}
